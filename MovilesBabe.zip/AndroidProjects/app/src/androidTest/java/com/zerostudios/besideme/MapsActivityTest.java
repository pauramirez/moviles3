package com.zerostudios.besideme;

import org.junit.Test;

import static org.junit.Assert.*;

public class MapsActivityTest {

    @Test
    public void onCreate() {
    }

    @Test
    public void onMapReady() {
    }

    @Test
    public void onConnected() {
    }

    @Test
    public void onConnectionSuspended() {
    }

    @Test
    public void onConnectionFailed() {
    }

    @Test
    public void onLocationChanged() {
    }
}